/**
 * @param {Element} node Node.
 * @return {string|null} href.
 */
export function readHref(node: Element): string | null;
//# sourceMappingURL=xlink.d.ts.map