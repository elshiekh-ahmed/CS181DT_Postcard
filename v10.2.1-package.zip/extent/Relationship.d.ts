declare namespace _default {
    let UNKNOWN: number;
    let INTERSECTING: number;
    let ABOVE: number;
    let RIGHT: number;
    let BELOW: number;
    let LEFT: number;
}
export default _default;
//# sourceMappingURL=Relationship.d.ts.map